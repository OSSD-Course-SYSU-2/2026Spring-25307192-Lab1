if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PacMan_Params {
    x?: number;
    y?: number;
    direction?: string;
    mouthAngle?: number;
    mouthDirection?: number;
    animationId?: number;
    onPositionChange?: (x: number, y: number) => void;
}
import { COLORS, GAME_CONFIG, Direction } from "@normalized:N&&&entry/src/main/ets/game/GameConstants&";
export class PacMan extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__x = new ObservedPropertySimplePU(14, this, "x");
        this.__y = new ObservedPropertySimplePU(23, this, "y");
        this.__direction = new ObservedPropertySimplePU(Direction.RIGHT, this, "direction");
        this.__mouthAngle = new ObservedPropertySimplePU(0.25 // 嘴巴开合角度（0-0.5）
        , this, "mouthAngle");
        this.__mouthDirection = new ObservedPropertySimplePU(1 // 嘴巴开合方向（1为张开，-1为闭合）
        // 动画相关
        , this, "mouthDirection");
        this.animationId = 0;
        this.onPositionChange = () => { };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PacMan_Params) {
        if (params.x !== undefined) {
            this.x = params.x;
        }
        if (params.y !== undefined) {
            this.y = params.y;
        }
        if (params.direction !== undefined) {
            this.direction = params.direction;
        }
        if (params.mouthAngle !== undefined) {
            this.mouthAngle = params.mouthAngle;
        }
        if (params.mouthDirection !== undefined) {
            this.mouthDirection = params.mouthDirection;
        }
        if (params.animationId !== undefined) {
            this.animationId = params.animationId;
        }
        if (params.onPositionChange !== undefined) {
            this.onPositionChange = params.onPositionChange;
        }
    }
    updateStateVars(params: PacMan_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__x.purgeDependencyOnElmtId(rmElmtId);
        this.__y.purgeDependencyOnElmtId(rmElmtId);
        this.__direction.purgeDependencyOnElmtId(rmElmtId);
        this.__mouthAngle.purgeDependencyOnElmtId(rmElmtId);
        this.__mouthDirection.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__x.aboutToBeDeleted();
        this.__y.aboutToBeDeleted();
        this.__direction.aboutToBeDeleted();
        this.__mouthAngle.aboutToBeDeleted();
        this.__mouthDirection.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 位置和方向
    private __x: ObservedPropertySimplePU<number>;
    get x() {
        return this.__x.get();
    }
    set x(newValue: number) {
        this.__x.set(newValue);
    }
    private __y: ObservedPropertySimplePU<number>;
    get y() {
        return this.__y.get();
    }
    set y(newValue: number) {
        this.__y.set(newValue);
    }
    private __direction: ObservedPropertySimplePU<string>;
    get direction() {
        return this.__direction.get();
    }
    set direction(newValue: string) {
        this.__direction.set(newValue);
    }
    private __mouthAngle: ObservedPropertySimplePU<number>; // 嘴巴开合角度（0-0.5）
    get mouthAngle() {
        return this.__mouthAngle.get();
    }
    set mouthAngle(newValue: number) {
        this.__mouthAngle.set(newValue);
    }
    private __mouthDirection: ObservedPropertySimplePU<number>; // 嘴巴开合方向（1为张开，-1为闭合）
    get mouthDirection() {
        return this.__mouthDirection.get();
    }
    set mouthDirection(newValue: number) {
        this.__mouthDirection.set(newValue);
    }
    // 动画相关
    private animationId: number;
    // 移动回调
    private onPositionChange: (x: number, y: number) => void;
    aboutToAppear() {
        this.startAnimation();
    }
    aboutToDisappear() {
        this.stopAnimation();
    }
    /**
     * 开始动画
     */
    private startAnimation(): void {
        this.stopAnimation();
        this.animationId = setInterval(() => {
            this.updateAnimation();
        }, 100); // 每100ms更新一次动画
    }
    /**
     * 停止动画
     */
    private stopAnimation(): void {
        if (this.animationId) {
            clearInterval(this.animationId);
            this.animationId = 0;
        }
    }
    /**
     * 更新动画
     */
    private updateAnimation(): void {
        // 更新嘴巴开合动画
        this.mouthAngle += 0.1 * this.mouthDirection;
        if (this.mouthAngle >= 0.5) {
            this.mouthAngle = 0.5;
            this.mouthDirection = -1;
        }
        else if (this.mouthAngle <= 0.1) {
            this.mouthAngle = 0.1;
            this.mouthDirection = 1;
        }
    }
    /**
     * 设置位置
     */
    public setPosition(x: number, y: number): void {
        this.x = x;
        this.y = y;
        this.onPositionChange(x, y);
    }
    /**
     * 获取位置
     */
    public getPosition(): {
        x: number;
        y: number;
    } {
        return { x: this.x, y: this.y };
    }
    /**
     * 设置方向
     */
    public setDirection(direction: string): void {
        this.direction = direction;
    }
    /**
     * 获取方向
     */
    public getDirection(): string {
        return this.direction;
    }
    /**
     * 移动吃豆人
     * @param canMove 是否可以移动到目标位置
     * @returns 是否移动成功
     */
    public move(canMove: (x: number, y: number) => boolean): boolean {
        let newX = this.x;
        let newY = this.y;
        // 根据方向计算新位置
        switch (this.direction) {
            case Direction.UP:
                newY -= 1;
                break;
            case Direction.DOWN:
                newY += 1;
                break;
            case Direction.LEFT:
                newX -= 1;
                break;
            case Direction.RIGHT:
                newX += 1;
                break;
        }
        // 检查是否可以移动
        if (canMove(newX, newY)) {
            this.setPosition(newX, newY);
            return true;
        }
        return false;
    }
    /**
     * 重置吃豆人
     */
    public reset(): void {
        this.x = 14;
        this.y = 23;
        this.direction = Direction.RIGHT;
        this.mouthAngle = 0.25;
        this.mouthDirection = 1;
        this.onPositionChange(this.x, this.y);
    }
    /**
     * 设置位置变化回调
     */
    public setOnPositionChange(callback: (x: number, y: number) => void): void {
        this.onPositionChange = callback;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 使用简单的图形代替Canvas
            Column.create();
            Column.debugLine("entry/src/main/ets/game/components/PacMan.ets(150:5)", "entry");
            // 使用简单的图形代替Canvas
            Column.width(GAME_CONFIG.GRID_SIZE);
            // 使用简单的图形代替Canvas
            Column.height(GAME_CONFIG.GRID_SIZE);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 吃豆人图形
            Row.create();
            Row.debugLine("entry/src/main/ets/game/components/PacMan.ets(152:7)", "entry");
            // 吃豆人图形
            Row.width(GAME_CONFIG.GRID_SIZE);
            // 吃豆人图形
            Row.height(GAME_CONFIG.GRID_SIZE);
            // 吃豆人图形
            Row.justifyContent(FlexAlign.Center);
            // 吃豆人图形
            Row.alignItems(HorizontalAlign.Center);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 根据方向绘制不同的图形
            if (this.direction === Direction.RIGHT) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 向右的吃豆人
                        Image.create($r('app.media.ic_public_right_filled'));
                        Image.debugLine("entry/src/main/ets/game/components/PacMan.ets(156:11)", "entry");
                        // 向右的吃豆人
                        Image.width(GAME_CONFIG.GRID_SIZE);
                        // 向右的吃豆人
                        Image.height(GAME_CONFIG.GRID_SIZE);
                        // 向右的吃豆人
                        Image.fillColor(COLORS.PACMAN);
                    }, Image);
                });
            }
            else if (this.direction === Direction.LEFT) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 向左的吃豆人
                        Image.create($r('app.media.ic_public_left_filled'));
                        Image.debugLine("entry/src/main/ets/game/components/PacMan.ets(162:11)", "entry");
                        // 向左的吃豆人
                        Image.width(GAME_CONFIG.GRID_SIZE);
                        // 向左的吃豆人
                        Image.height(GAME_CONFIG.GRID_SIZE);
                        // 向左的吃豆人
                        Image.fillColor(COLORS.PACMAN);
                    }, Image);
                });
            }
            else if (this.direction === Direction.UP) {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 向上的吃豆人
                        Image.create($r('app.media.ic_public_up_filled'));
                        Image.debugLine("entry/src/main/ets/game/components/PacMan.ets(168:11)", "entry");
                        // 向上的吃豆人
                        Image.width(GAME_CONFIG.GRID_SIZE);
                        // 向上的吃豆人
                        Image.height(GAME_CONFIG.GRID_SIZE);
                        // 向上的吃豆人
                        Image.fillColor(COLORS.PACMAN);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(3, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 向下的吃豆人
                        Image.create($r('app.media.ic_public_down_filled'));
                        Image.debugLine("entry/src/main/ets/game/components/PacMan.ets(174:11)", "entry");
                        // 向下的吃豆人
                        Image.width(GAME_CONFIG.GRID_SIZE);
                        // 向下的吃豆人
                        Image.height(GAME_CONFIG.GRID_SIZE);
                        // 向下的吃豆人
                        Image.fillColor(COLORS.PACMAN);
                    }, Image);
                });
            }
        }, If);
        If.pop();
        // 吃豆人图形
        Row.pop();
        // 使用简单的图形代替Canvas
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
