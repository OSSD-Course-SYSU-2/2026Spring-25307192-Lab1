import { GameState, Direction, GameConfig, MapElements, MAZE_MAP } from "@normalized:N&&&entry/src/main/ets/game/GameConstants&";
/**
 * 游戏核心逻辑类
 */
export class GameLogic {
    // 游戏状态
    private gameState: string = GameState.MENU;
    private score: number = 0;
    private highScore: number = 0;
    private level: number = 1;
    private lives: number = GameConfig.LIVES;
    private dotsRemaining: number = 0;
    // 吃豆人位置和方向
    private pacmanX: number = 14;
    private pacmanY: number = 23;
    private pacmanDirection: string = Direction.RIGHT;
    // 地图数据
    private mazeData: string[][] = [];
    private dots: boolean[][] = [];
    private powerPellets: boolean[][] = [];
    // 回调函数
    private onStateChange: (state: string) => void = () => { };
    private onScoreChange: (score: number) => void = () => { };
    private onHighScoreChange: (highScore: number) => void = () => { };
    private onLevelChange: (level: number) => void = () => { };
    private onLivesChange: (lives: number) => void = () => { };
    private onDotsChange: (dots: number) => void = () => { };
    private onPacmanMove: (x: number, y: number) => void = () => { };
    constructor() {
        this.initializeMaze();
    }
    /**
     * 初始化迷宫
     */
    private initializeMaze(): void {
        // 解析地图数据
        this.mazeData = MAZE_MAP.map(row => row.split(''));
        // 初始化豆子状态
        this.dots = [];
        this.powerPellets = [];
        this.dotsRemaining = 0;
        for (let y = 0; y < GameConfig.MAZE_HEIGHT; y++) {
            this.dots[y] = [];
            this.powerPellets[y] = [];
            for (let x = 0; x < GameConfig.MAZE_WIDTH; x++) {
                const cell = this.mazeData[y][x];
                if (cell === MapElements.PATH) {
                    this.dots[y][x] = true;
                    this.powerPellets[y][x] = false;
                    this.dotsRemaining++;
                }
                else if (cell === MapElements.POWER_PELLET) {
                    this.dots[y][x] = false;
                    this.powerPellets[y][x] = true;
                    this.dotsRemaining++;
                }
                else {
                    this.dots[y][x] = false;
                    this.powerPellets[y][x] = false;
                }
            }
        }
        this.onDotsChange(this.dotsRemaining);
    }
    /**
     * 开始游戏
     */
    public startGame(): void {
        if (this.gameState === GameState.MENU || this.gameState === GameState.GAME_OVER) {
            this.gameState = GameState.PLAYING;
            this.score = 0;
            this.level = 1;
            this.lives = GameConfig.LIVES;
            this.pacmanX = 14;
            this.pacmanY = 23;
            this.pacmanDirection = Direction.RIGHT;
            this.initializeMaze();
            this.onStateChange(this.gameState);
            this.onScoreChange(this.score);
            this.onLevelChange(this.level);
            this.onLivesChange(this.lives);
            this.onPacmanMove(this.pacmanX, this.pacmanY);
        }
    }
    /**
     * 暂停游戏
     */
    public pauseGame(): void {
        if (this.gameState === GameState.PLAYING) {
            this.gameState = GameState.PAUSED;
            this.onStateChange(this.gameState);
        }
    }
    /**
     * 继续游戏
     */
    public resumeGame(): void {
        if (this.gameState === GameState.PAUSED) {
            this.gameState = GameState.PLAYING;
            this.onStateChange(this.gameState);
        }
    }
    /**
     * 重新开始游戏
     */
    public restartGame(): void {
        this.gameState = GameState.PLAYING;
        this.score = 0;
        this.level = 1;
        this.lives = GameConfig.LIVES;
        this.pacmanX = 14;
        this.pacmanY = 23;
        this.pacmanDirection = Direction.RIGHT;
        this.initializeMaze();
        this.onStateChange(this.gameState);
        this.onScoreChange(this.score);
        this.onLevelChange(this.level);
        this.onLivesChange(this.lives);
        this.onPacmanMove(this.pacmanX, this.pacmanY);
    }
    /**
     * 移动吃豆人
     */
    public movePacman(direction: string): void {
        if (this.gameState !== GameState.PLAYING)
            return;
        this.pacmanDirection = direction;
        let newX = this.pacmanX;
        let newY = this.pacmanY;
        // 根据方向计算新位置
        switch (direction) {
            case Direction.UP:
                newY -= 1;
                break;
            case Direction.DOWN:
                newY += 1;
                break;
            case Direction.LEFT:
                newX -= 1;
                break;
            case Direction.RIGHT:
                newX += 1;
                break;
        }
        // 检查是否可以移动
        if (this.canMoveTo(newX, newY)) {
            this.pacmanX = newX;
            this.pacmanY = newY;
            this.onPacmanMove(this.pacmanX, this.pacmanY);
            // 检查是否吃到豆子
            this.eatDot(newX, newY);
            // 检查游戏条件
            this.checkGameConditions();
        }
    }
    /**
     * 检查是否可以移动到指定位置
     */
    private canMoveTo(x: number, y: number): boolean {
        if (x < 0 || x >= GameConfig.MAZE_WIDTH || y < 0 || y >= GameConfig.MAZE_HEIGHT) {
            return false;
        }
        const cell = this.mazeData[y][x];
        return cell !== MapElements.WALL;
    }
    /**
     * 吃豆子
     */
    private eatDot(x: number, y: number): void {
        if (this.dots[y][x]) {
            this.dots[y][x] = false;
            this.score += GameConfig.DOT_SCORE;
            this.dotsRemaining--;
            this.onScoreChange(this.score);
            this.onDotsChange(this.dotsRemaining);
        }
        else if (this.powerPellets[y][x]) {
            this.powerPellets[y][x] = false;
            this.score += GameConfig.POWER_PELLET_SCORE;
            this.dotsRemaining--;
            this.onScoreChange(this.score);
            this.onDotsChange(this.dotsRemaining);
        }
    }
    /**
     * 检查游戏条件
     */
    private checkGameConditions(): void {
        // 检查是否吃完所有豆子
        if (this.dotsRemaining <= 0) {
            this.completeLevel();
            return;
        }
        // 随机模拟幽灵碰撞
        if (Math.random() > 0.995 && this.lives > 0) {
            this.lives--;
            this.onLivesChange(this.lives);
            if (this.lives <= 0) {
                this.gameOver();
            }
        }
    }
    /**
     * 完成关卡
     */
    private completeLevel(): void {
        this.gameState = GameState.LEVEL_COMPLETE;
        // 计算关卡奖励分数
        const levelBonus = this.level * GameConfig.LEVEL_SCORE_MULTIPLIER;
        this.score += levelBonus;
        this.level++;
        this.onStateChange(this.gameState);
        this.onScoreChange(this.score);
        this.onLevelChange(this.level);
        // 延迟后自动开始下一关
        setTimeout(() => {
            if (this.gameState === GameState.LEVEL_COMPLETE) {
                this.restartGame();
            }
        }, 2000);
    }
    /**
     * 游戏结束
     */
    private gameOver(): void {
        this.gameState = GameState.GAME_OVER;
        // 更新最高分
        if (this.score > this.highScore) {
            this.highScore = this.score;
            this.onHighScoreChange(this.highScore);
        }
        this.onStateChange(this.gameState);
    }
    /**
     * 获取游戏状态
     */
    public getGameState(): string {
        return this.gameState;
    }
    /**
     * 获取分数
     */
    public getScore(): number {
        return this.score;
    }
    /**
     * 获取最高分
     */
    public getHighScore(): number {
        return this.highScore;
    }
    /**
     * 获取关卡
     */
    public getLevel(): number {
        return this.level;
    }
    /**
     * 获取生命
     */
    public getLives(): number {
        return this.lives;
    }
    /**
     * 获取剩余豆子
     */
    public getDotsRemaining(): number {
        return this.dotsRemaining;
    }
    /**
     * 获取吃豆人位置
     */
    public getPacmanPosition(): {
        x: number;
        y: number;
    } {
        return { x: this.pacmanX, y: this.pacmanY };
    }
    /**
     * 获取吃豆人方向
     */
    public getPacmanDirection(): string {
        return this.pacmanDirection;
    }
    /**
     * 获取地图数据
     */
    public getMazeData(): string[][] {
        return this.mazeData;
    }
    /**
     * 获取豆子状态
     */
    public getDots(): boolean[][] {
        return this.dots;
    }
    /**
     * 获取大力丸状态
     */
    public getPowerPellets(): boolean[][] {
        return this.powerPellets;
    }
    /**
     * 设置回调函数
     */
    public setCallbacks(onStateChange: (state: string) => void, onScoreChange: (score: number) => void, onHighScoreChange: (highScore: number) => void, onLevelChange: (level: number) => void, onLivesChange: (lives: number) => void, onDotsChange: (dots: number) => void, onPacmanMove: (x: number, y: number) => void): void {
        this.onStateChange = onStateChange;
        this.onScoreChange = onScoreChange;
        this.onHighScoreChange = onHighScoreChange;
        this.onLevelChange = onLevelChange;
        this.onLivesChange = onLivesChange;
        this.onDotsChange = onDotsChange;
        this.onPacmanMove = onPacmanMove;
    }
}
