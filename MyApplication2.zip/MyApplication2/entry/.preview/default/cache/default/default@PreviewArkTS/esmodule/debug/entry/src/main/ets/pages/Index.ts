if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    gameState?: string;
    score?: number;
    highScore?: number;
    level?: number;
    lives?: number;
    dotsRemaining?: number;
    pacmanX?: number;
    pacmanY?: number;
    pacmanDirection?: string;
    gameTimer?: number;
    mazeData?: string[][];
    dots?: boolean[][];
    gridSize?: number;
    rows?: number[];
    cols?: number[];
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__gameState = new ObservedPropertySimplePU('menu', this, "gameState");
        this.__score = new ObservedPropertySimplePU(0, this, "score");
        this.__highScore = new ObservedPropertySimplePU(0, this, "highScore");
        this.__level = new ObservedPropertySimplePU(1, this, "level");
        this.__lives = new ObservedPropertySimplePU(3, this, "lives");
        this.__dotsRemaining = new ObservedPropertySimplePU(244 // 初始豆子数量
        // 吃豆人位置 - 修正为可移动的空地位置 (1, 1)
        , this, "dotsRemaining");
        this.__pacmanX = new ObservedPropertySimplePU(1, this, "pacmanX");
        this.__pacmanY = new ObservedPropertySimplePU(1, this, "pacmanY");
        this.__pacmanDirection = new ObservedPropertySimplePU('right'
        // 游戏定时器
        , this, "pacmanDirection");
        this.gameTimer = 0;
        this.mazeData = [
            ['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'],
            ['#', '.', '.', '.', '.', '.', '.', '#', '.', '.', '.', '.', '.', '#'],
            ['#', '.', '#', '#', '#', '#', '.', '#', '.', '#', '#', '#', '.', '#'],
            ['#', '.', '#', '#', '#', '#', '.', '#', '.', '#', '#', '#', '.', '#'],
            ['#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#'],
            ['#', '#', '#', '.', '#', '#', '#', '#', '#', '#', '#', '.', '#', '#'],
            ['#', '#', '#', '.', '#', '#', '#', '#', '#', '#', '#', '.', '#', '#'],
            ['#', '.', '.', '.', '.', '.', '#', '#', '.', '.', '.', '.', '.', '#'],
            ['#', '.', '#', '#', '#', '.', '#', '#', '.', '#', '#', '#', '.', '#'],
            ['#', '.', '#', '#', '#', '.', '#', '#', '.', '#', '#', '#', '.', '#'],
            ['#', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '#'],
            ['#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#']
        ];
        this.__dots = new ObservedPropertyObjectPU([]
        // 网格大小
        , this, "dots");
        this.gridSize = 30;
        this.rows = [];
        this.cols = [];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.gameState !== undefined) {
            this.gameState = params.gameState;
        }
        if (params.score !== undefined) {
            this.score = params.score;
        }
        if (params.highScore !== undefined) {
            this.highScore = params.highScore;
        }
        if (params.level !== undefined) {
            this.level = params.level;
        }
        if (params.lives !== undefined) {
            this.lives = params.lives;
        }
        if (params.dotsRemaining !== undefined) {
            this.dotsRemaining = params.dotsRemaining;
        }
        if (params.pacmanX !== undefined) {
            this.pacmanX = params.pacmanX;
        }
        if (params.pacmanY !== undefined) {
            this.pacmanY = params.pacmanY;
        }
        if (params.pacmanDirection !== undefined) {
            this.pacmanDirection = params.pacmanDirection;
        }
        if (params.gameTimer !== undefined) {
            this.gameTimer = params.gameTimer;
        }
        if (params.mazeData !== undefined) {
            this.mazeData = params.mazeData;
        }
        if (params.dots !== undefined) {
            this.dots = params.dots;
        }
        if (params.gridSize !== undefined) {
            this.gridSize = params.gridSize;
        }
        if (params.rows !== undefined) {
            this.rows = params.rows;
        }
        if (params.cols !== undefined) {
            this.cols = params.cols;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__gameState.purgeDependencyOnElmtId(rmElmtId);
        this.__score.purgeDependencyOnElmtId(rmElmtId);
        this.__highScore.purgeDependencyOnElmtId(rmElmtId);
        this.__level.purgeDependencyOnElmtId(rmElmtId);
        this.__lives.purgeDependencyOnElmtId(rmElmtId);
        this.__dotsRemaining.purgeDependencyOnElmtId(rmElmtId);
        this.__pacmanX.purgeDependencyOnElmtId(rmElmtId);
        this.__pacmanY.purgeDependencyOnElmtId(rmElmtId);
        this.__pacmanDirection.purgeDependencyOnElmtId(rmElmtId);
        this.__dots.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__gameState.aboutToBeDeleted();
        this.__score.aboutToBeDeleted();
        this.__highScore.aboutToBeDeleted();
        this.__level.aboutToBeDeleted();
        this.__lives.aboutToBeDeleted();
        this.__dotsRemaining.aboutToBeDeleted();
        this.__pacmanX.aboutToBeDeleted();
        this.__pacmanY.aboutToBeDeleted();
        this.__pacmanDirection.aboutToBeDeleted();
        this.__dots.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 游戏状态
    private __gameState: ObservedPropertySimplePU<string>;
    get gameState() {
        return this.__gameState.get();
    }
    set gameState(newValue: string) {
        this.__gameState.set(newValue);
    }
    private __score: ObservedPropertySimplePU<number>;
    get score() {
        return this.__score.get();
    }
    set score(newValue: number) {
        this.__score.set(newValue);
    }
    private __highScore: ObservedPropertySimplePU<number>;
    get highScore() {
        return this.__highScore.get();
    }
    set highScore(newValue: number) {
        this.__highScore.set(newValue);
    }
    private __level: ObservedPropertySimplePU<number>;
    get level() {
        return this.__level.get();
    }
    set level(newValue: number) {
        this.__level.set(newValue);
    }
    private __lives: ObservedPropertySimplePU<number>;
    get lives() {
        return this.__lives.get();
    }
    set lives(newValue: number) {
        this.__lives.set(newValue);
    }
    private __dotsRemaining: ObservedPropertySimplePU<number>; // 初始豆子数量
    get dotsRemaining() {
        return this.__dotsRemaining.get();
    }
    set dotsRemaining(newValue: number) {
        this.__dotsRemaining.set(newValue);
    }
    // 吃豆人位置 - 修正为可移动的空地位置 (1, 1)
    private __pacmanX: ObservedPropertySimplePU<number>;
    get pacmanX() {
        return this.__pacmanX.get();
    }
    set pacmanX(newValue: number) {
        this.__pacmanX.set(newValue);
    }
    private __pacmanY: ObservedPropertySimplePU<number>;
    get pacmanY() {
        return this.__pacmanY.get();
    }
    set pacmanY(newValue: number) {
        this.__pacmanY.set(newValue);
    }
    private __pacmanDirection: ObservedPropertySimplePU<string>;
    get pacmanDirection() {
        return this.__pacmanDirection.get();
    }
    set pacmanDirection(newValue: string) {
        this.__pacmanDirection.set(newValue);
    }
    // 游戏定时器
    private gameTimer: number;
    // 迷宫地图数据（简化版 12x14）
    private mazeData: string[][];
    // 豆子状态
    private __dots: ObservedPropertyObjectPU<boolean[][]>;
    get dots() {
        return this.__dots.get();
    }
    set dots(newValue: boolean[][]) {
        this.__dots.set(newValue);
    }
    // 网格大小
    private gridSize: number;
    // 行和列数组（用于ForEach）
    private rows: number[];
    private cols: number[];
    aboutToAppear() {
        // 初始化行和列数组
        this.rows = [];
        for (let i = 0; i < this.mazeData.length; i++) {
            this.rows.push(i);
        }
        this.cols = [];
        for (let i = 0; i < this.mazeData[0].length; i++) {
            this.cols.push(i);
        }
        // 初始化豆子状态
        this.initializeDots();
    }
    aboutToDisappear() {
        this.stopGameLoop();
    }
    /**
     * 初始化豆子状态
     */
    private initializeDots(): void {
        const newDots: boolean[][] = [];
        for (let y = 0; y < this.mazeData.length; y++) {
            newDots[y] = [];
            for (let x = 0; x < this.mazeData[y].length; x++) {
                newDots[y][x] = this.mazeData[y][x] === '.';
            }
        }
        this.dots = newDots;
    }
    /**
     * 开始游戏
     */
    private startGame(): void {
        if (this.gameState === 'menu' || this.gameState === 'game_over') {
            this.gameState = 'playing';
            this.score = 0;
            this.level = 1;
            this.lives = 3;
            this.pacmanX = 1;
            this.pacmanY = 1;
            this.pacmanDirection = 'right';
            this.dotsRemaining = 244;
            this.initializeDots();
            // 开始游戏循环
            this.startGameLoop();
        }
    }
    /**
     * 暂停游戏
     */
    private pauseGame(): void {
        if (this.gameState === 'playing') {
            this.gameState = 'paused';
            this.stopGameLoop();
        }
    }
    /**
     * 继续游戏
     */
    private resumeGame(): void {
        if (this.gameState === 'paused') {
            this.gameState = 'playing';
            this.startGameLoop();
        }
    }
    /**
     * 重新开始游戏
     */
    private restartGame(): void {
        this.gameState = 'playing';
        this.score = 0;
        this.level = 1;
        this.lives = 3;
        this.pacmanX = 1;
        this.pacmanY = 1;
        this.pacmanDirection = 'right';
        this.dotsRemaining = 244;
        this.initializeDots();
        // 开始游戏循环
        this.startGameLoop();
    }
    /**
     * 开始游戏循环
     */
    private startGameLoop(): void {
        this.stopGameLoop();
        // 每200ms自动移动一次
        this.gameTimer = setInterval(() => {
            if (this.gameState === 'playing') {
                // 保持当前方向移动
                this.movePacmanInCurrentDirection();
                console.log(`游戏循环: 吃豆人位置 (${this.pacmanX}, ${this.pacmanY}), 方向: ${this.pacmanDirection}`);
            }
        }, 200);
    }
    /**
     * 停止游戏循环
     */
    private stopGameLoop(): void {
        if (this.gameTimer) {
            clearInterval(this.gameTimer);
            this.gameTimer = 0;
        }
    }
    /**
     * 移动吃豆人到指定位置（内部方法）
     */
    private moveToPosition(newX: number, newY: number, direction: string): void {
        // 更新吃豆人位置
        this.pacmanX = newX;
        this.pacmanY = newY;
        console.log(`吃豆人移动到: (${newX}, ${newY}), 方向: ${direction}`);
        // 检查是否吃到豆子
        this.eatDot(newX, newY);
        // 检查游戏条件
        this.checkGameConditions();
    }
    /**
     * 移动吃豆人
     */
    private movePacman(direction: string): void {
        if (this.gameState !== 'playing')
            return;
        let newX = this.pacmanX;
        let newY = this.pacmanY;
        // 根据方向计算新位置
        switch (direction) {
            case 'up':
                newY -= 1;
                break;
            case 'down':
                newY += 1;
                break;
            case 'left':
                newX -= 1;
                break;
            case 'right':
                newX += 1;
                break;
        }
        // 检查是否可以移动（撞墙检测）
        if (this.canMoveTo(newX, newY)) {
            this.moveToPosition(newX, newY, direction);
        }
        else {
            console.log(`无法移动到: (${newX}, ${newY}), 方向: ${direction}, 当前位置: (${this.pacmanX}, ${this.pacmanY})`);
        }
    }
    /**
     * 检查是否可以移动到指定位置
     */
    private canMoveTo(x: number, y: number): boolean {
        if (x < 0 || x >= this.mazeData[0].length || y < 0 || y >= this.mazeData.length) {
            return false;
        }
        const cell = this.mazeData[y][x];
        return cell !== '#';
    }
    /**
     * 吃豆子
     */
    private eatDot(x: number, y: number): void {
        if (this.dots[y] && this.dots[y][x]) {
            // 创建新的数组以触发UI更新
            const newDots = [...this.dots];
            newDots[y] = [...newDots[y]];
            newDots[y][x] = false;
            this.dots = newDots;
            this.score += 10;
            this.dotsRemaining--;
            // 检查是否吃完所有豆子
            if (this.dotsRemaining <= 0) {
                this.completeLevel();
            }
        }
    }
    /**
     * 检查游戏条件
     */
    private checkGameConditions(): void {
        // 随机模拟幽灵碰撞（简化版）
        if (Math.random() > 0.995 && this.lives > 0) {
            this.lives--;
            if (this.lives <= 0) {
                this.gameOver();
            }
        }
    }
    /**
     * 完成关卡
     */
    private completeLevel(): void {
        this.gameState = 'level_complete';
        // 计算关卡奖励分数
        const levelBonus = this.level * 1000;
        this.score += levelBonus;
        this.level++;
        // 延迟后自动开始下一关
        setTimeout(() => {
            if (this.gameState === 'level_complete') {
                this.restartGame();
            }
        }, 2000);
    }
    /**
     * 游戏结束
     */
    private gameOver(): void {
        this.gameState = 'game_over';
        this.stopGameLoop();
        // 更新最高分
        if (this.score > this.highScore) {
            this.highScore = this.score;
        }
    }
    /**
     * 处理键盘事件
     */
    private handleKeyEvent(event: KeyEvent): void {
        if (event.type === KeyType.Down) {
            switch (event.keyCode) {
                case 1001: // Enter键 - 开始游戏
                    if (this.gameState === 'menu' || this.gameState === 'game_over') {
                        this.startGame();
                    }
                    break;
                case 1002: // 空格键 - 暂停/继续
                    if (this.gameState === 'playing') {
                        this.pauseGame();
                    }
                    else if (this.gameState === 'paused') {
                        this.resumeGame();
                    }
                    break;
                case 203: // 上箭头
                    this.setPacmanDirection('up');
                    break;
                case 204: // 下箭头
                    this.setPacmanDirection('down');
                    break;
                case 205: // 左箭头
                    this.setPacmanDirection('left');
                    break;
                case 206: // 右箭头
                    this.setPacmanDirection('right');
                    break;
            }
        }
    }
    /**
     * 设置吃豆人方向并立即移动
     */
    private setPacmanDirection(direction: string): void {
        if (this.gameState !== 'playing')
            return;
        // 更新方向
        this.pacmanDirection = direction;
        console.log(`方向键按下: ${direction}, 当前位置: (${this.pacmanX}, ${this.pacmanY})`);
        // 立即移动一次，让玩家感觉响应迅速
        this.movePacman(direction);
    }
    /**
     * 按当前方向移动吃豆人
     */
    private movePacmanInCurrentDirection(): void {
        if (this.gameState !== 'playing')
            return;
        let newX = this.pacmanX;
        let newY = this.pacmanY;
        // 根据当前方向计算新位置
        switch (this.pacmanDirection) {
            case 'up':
                newY -= 1;
                break;
            case 'down':
                newY += 1;
                break;
            case 'left':
                newX -= 1;
                break;
            case 'right':
                newX += 1;
                break;
        }
        // 检查是否可以移动（撞墙检测）
        if (this.canMoveTo(newX, newY)) {
            this.moveToPosition(newX, newY, this.pacmanDirection);
        }
        else {
            console.log(`游戏循环无法移动: (${newX}, ${newY}), 方向: ${this.pacmanDirection}, 当前位置: (${this.pacmanX}, ${this.pacmanY})`);
        }
    }
    /**
     * 获取游戏状态文本
     */
    private getGameStateText(): string {
        switch (this.gameState) {
            case 'menu':
                return '菜单';
            case 'playing':
                return '游戏中';
            case 'paused':
                return '暂停';
            case 'game_over':
                return '游戏结束';
            case 'level_complete':
                return '关卡完成';
            default:
                return '未知';
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(401:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Start);
            Column.alignItems(HorizontalAlign.Center);
            Column.padding(20);
            Column.backgroundColor('#000000');
            Column.onKeyEvent((event: KeyEvent) => {
                this.handleKeyEvent(event);
            });
            Column.focusable(true);
            Column.focusOnTouch(true);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 游戏标题
            Text.create('吃豆人小游戏');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(403:7)", "entry");
            // 游戏标题
            Text.fontSize(30);
            // 游戏标题
            Text.fontWeight(FontWeight.Bold);
            // 游戏标题
            Text.fontColor('#FFFF00');
            // 游戏标题
            Text.margin({ bottom: 10 });
        }, Text);
        // 游戏标题
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 游戏地图 - 使用Stack布局
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/Index.ets(410:7)", "entry");
            // 游戏地图 - 使用Stack布局
            Stack.width(this.mazeData[0].length * this.gridSize);
            // 游戏地图 - 使用Stack布局
            Stack.height(this.mazeData.length * this.gridSize);
            // 游戏地图 - 使用Stack布局
            Stack.border({ width: 2, color: '#0000FF' });
            // 游戏地图 - 使用Stack布局
            Stack.margin({ bottom: 20 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 绘制迷宫背景
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(412:9)", "entry");
            // 绘制迷宫背景
            Column.width(this.mazeData[0].length * this.gridSize);
            // 绘制迷宫背景
            Column.height(this.mazeData.length * this.gridSize);
            // 绘制迷宫背景
            Column.backgroundColor('#000000');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 渲染每一行
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const y = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/pages/Index.ets(415:13)", "entry");
                    Row.width('100%');
                    Row.height(this.gridSize);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    // 渲染每一列
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const x = _item;
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            // 渲染单个单元格
                            Column.create();
                            Column.debugLine("entry/src/main/ets/pages/Index.ets(419:17)", "entry");
                            // 渲染单个单元格
                            Column.width(this.gridSize);
                            // 渲染单个单元格
                            Column.height(this.gridSize);
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            If.create();
                            if (this.mazeData[y][x] === '#') {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // 墙壁 - 蓝色方块
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/Index.ets(422:21)", "entry");
                                        // 墙壁 - 蓝色方块
                                        Row.width(this.gridSize);
                                        // 墙壁 - 蓝色方块
                                        Row.height(this.gridSize);
                                        // 墙壁 - 蓝色方块
                                        Row.backgroundColor('#0000FF');
                                        // 墙壁 - 蓝色方块
                                        Row.border({ width: 1, color: '#0000AA' });
                                    }, Row);
                                    // 墙壁 - 蓝色方块
                                    Row.pop();
                                });
                            }
                            else if (this.dots[y] && this.dots[y][x]) {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // 小豆子 - 白色小圆点
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/Index.ets(429:21)", "entry");
                                        // 小豆子 - 白色小圆点
                                        Column.width(this.gridSize);
                                        // 小豆子 - 白色小圆点
                                        Column.height(this.gridSize);
                                        // 小豆子 - 白色小圆点
                                        Column.justifyContent(FlexAlign.Center);
                                        // 小豆子 - 白色小圆点
                                        Column.alignItems(HorizontalAlign.Center);
                                        // 小豆子 - 白色小圆点
                                        Column.backgroundColor('#000000');
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Circle.create({ width: this.gridSize / 4, height: this.gridSize / 4 });
                                        Circle.debugLine("entry/src/main/ets/pages/Index.ets(430:23)", "entry");
                                        Circle.fill('#FFFFFF');
                                    }, Circle);
                                    // 小豆子 - 白色小圆点
                                    Column.pop();
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(2, () => {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // 空地 - 黑色背景
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/Index.ets(440:21)", "entry");
                                        // 空地 - 黑色背景
                                        Row.width(this.gridSize);
                                        // 空地 - 黑色背景
                                        Row.height(this.gridSize);
                                        // 空地 - 黑色背景
                                        Row.backgroundColor('#000000');
                                    }, Row);
                                    // 空地 - 黑色背景
                                    Row.pop();
                                });
                            }
                        }, If);
                        If.pop();
                        // 渲染单个单元格
                        Column.pop();
                    };
                    this.forEachUpdateFunction(elmtId, this.cols, forEachItemGenFunction);
                }, ForEach);
                // 渲染每一列
                ForEach.pop();
                Row.pop();
            };
            this.forEachUpdateFunction(elmtId, this.rows, forEachItemGenFunction);
        }, ForEach);
        // 渲染每一行
        ForEach.pop();
        // 绘制迷宫背景
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 绘制吃豆人
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(459:9)", "entry");
            // 绘制吃豆人
            Column.position({
                x: this.pacmanX * this.gridSize,
                y: this.pacmanY * this.gridSize
            });
            // 绘制吃豆人
            Column.width(this.gridSize);
            // 绘制吃豆人
            Column.height(this.gridSize);
            // 绘制吃豆人
            Column.justifyContent(FlexAlign.Center);
            // 绘制吃豆人
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Circle.create({ width: this.gridSize - 4, height: this.gridSize - 4 });
            Circle.debugLine("entry/src/main/ets/pages/Index.ets(460:11)", "entry");
            Circle.fill('#FFFF00');
        }, Circle);
        // 绘制吃豆人
        Column.pop();
        // 游戏地图 - 使用Stack布局
        Stack.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 游戏状态显示面板
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(478:7)", "entry");
            // 游戏状态显示面板
            Column.width('90%');
            // 游戏状态显示面板
            Column.padding(15);
            // 游戏状态显示面板
            Column.backgroundColor('#222222');
            // 游戏状态显示面板
            Column.borderRadius(10);
            // 游戏状态显示面板
            Column.margin({ bottom: 20 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`游戏状态: ${this.getGameStateText()}`);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(479:9)", "entry");
            Text.fontSize(16);
            Text.fontColor('#FFFFFF');
            Text.margin({ bottom: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`分数: ${this.score}`);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(484:9)", "entry");
            Text.fontSize(16);
            Text.fontColor('#FFFFFF');
            Text.margin({ bottom: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`最高分: ${this.highScore}`);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(489:9)", "entry");
            Text.fontSize(16);
            Text.fontColor('#FFFFFF');
            Text.margin({ bottom: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`关卡: ${this.level}`);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(494:9)", "entry");
            Text.fontSize(16);
            Text.fontColor('#FFFFFF');
            Text.margin({ bottom: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`生命: ${this.lives}`);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(499:9)", "entry");
            Text.fontSize(16);
            Text.fontColor('#FFFFFF');
            Text.margin({ bottom: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`剩余豆子: ${this.dotsRemaining}`);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(504:9)", "entry");
            Text.fontSize(16);
            Text.fontColor('#FFFFFF');
            Text.margin({ bottom: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 吃豆人位置显示
            Text.create(`吃豆人位置: (${this.pacmanX}, ${this.pacmanY})`);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(510:9)", "entry");
            // 吃豆人位置显示
            Text.fontSize(14);
            // 吃豆人位置显示
            Text.fontColor('#FFFF00');
            // 吃豆人位置显示
            Text.margin({ bottom: 5 });
        }, Text);
        // 吃豆人位置显示
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`方向: ${this.pacmanDirection}`);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(515:9)", "entry");
            Text.fontSize(14);
            Text.fontColor('#FFFF00');
            Text.margin({ bottom: 10 });
        }, Text);
        Text.pop();
        // 游戏状态显示面板
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 虚拟方向控制按钮
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(527:7)", "entry");
            // 虚拟方向控制按钮
            Column.width('100%');
            // 虚拟方向控制按钮
            Column.alignItems(HorizontalAlign.Center);
            // 虚拟方向控制按钮
            Column.margin({ bottom: 20 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 上
            Button.createWithLabel('↑');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(529:9)", "entry");
            // 上
            Button.width(80);
            // 上
            Button.height(80);
            // 上
            Button.fontSize(32);
            // 上
            Button.fontWeight(FontWeight.Bold);
            // 上
            Button.fontColor('#000000');
            // 上
            Button.backgroundColor('#FFFFFF');
            // 上
            Button.borderRadius(40);
            // 上
            Button.margin({ bottom: 5 });
            // 上
            Button.onClick(() => {
                if (this.gameState === 'playing') {
                    this.setPacmanDirection('up');
                }
            });
        }, Button);
        // 上
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(544:9)", "entry");
            Row.margin({ bottom: 5 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 左
            Button.createWithLabel('←');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(546:11)", "entry");
            // 左
            Button.width(80);
            // 左
            Button.height(80);
            // 左
            Button.fontSize(32);
            // 左
            Button.fontWeight(FontWeight.Bold);
            // 左
            Button.fontColor('#000000');
            // 左
            Button.backgroundColor('#FFFFFF');
            // 左
            Button.borderRadius(40);
            // 左
            Button.margin({ right: 10 });
            // 左
            Button.onClick(() => {
                if (this.gameState === 'playing') {
                    this.setPacmanDirection('left');
                }
            });
        }, Button);
        // 左
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 中间占位
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(562:11)", "entry");
            // 中间占位
            Blank.width(80);
            // 中间占位
            Blank.height(80);
        }, Blank);
        // 中间占位
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 右
            Button.createWithLabel('→');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(567:11)", "entry");
            // 右
            Button.width(80);
            // 右
            Button.height(80);
            // 右
            Button.fontSize(32);
            // 右
            Button.fontWeight(FontWeight.Bold);
            // 右
            Button.fontColor('#000000');
            // 右
            Button.backgroundColor('#FFFFFF');
            // 右
            Button.borderRadius(40);
            // 右
            Button.margin({ left: 10 });
            // 右
            Button.onClick(() => {
                if (this.gameState === 'playing') {
                    this.setPacmanDirection('right');
                }
            });
        }, Button);
        // 右
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 下
            Button.createWithLabel('↓');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(585:9)", "entry");
            // 下
            Button.width(80);
            // 下
            Button.height(80);
            // 下
            Button.fontSize(32);
            // 下
            Button.fontWeight(FontWeight.Bold);
            // 下
            Button.fontColor('#000000');
            // 下
            Button.backgroundColor('#FFFFFF');
            // 下
            Button.borderRadius(40);
            // 下
            Button.margin({ top: 5 });
            // 下
            Button.onClick(() => {
                if (this.gameState === 'playing') {
                    this.setPacmanDirection('down');
                }
            });
        }, Button);
        // 下
        Button.pop();
        // 虚拟方向控制按钮
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 控制按钮区域
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(605:7)", "entry");
            // 控制按钮区域
            Row.justifyContent(FlexAlign.Center);
            // 控制按钮区域
            Row.width('100%');
            // 控制按钮区域
            Row.margin({ bottom: 20 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('开始游戏');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(606:9)", "entry");
            Button.backgroundColor('#FFFF00');
            Button.fontColor('#000000');
            Button.fontSize(16);
            Button.margin(10);
            Button.onClick(() => {
                if (this.gameState === 'menu' || this.gameState === 'game_over') {
                    this.startGame();
                }
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.gameState === 'playing' ? '暂停' : '继续');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(617:9)", "entry");
            Button.backgroundColor('#FF0000');
            Button.fontColor('#FFFFFF');
            Button.fontSize(16);
            Button.margin(10);
            Button.onClick(() => {
                if (this.gameState === 'playing') {
                    this.pauseGame();
                }
                else if (this.gameState === 'paused') {
                    this.resumeGame();
                }
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('重新开始');
            Button.debugLine("entry/src/main/ets/pages/Index.ets(630:9)", "entry");
            Button.backgroundColor('#00FFFF');
            Button.fontColor('#000000');
            Button.fontSize(16);
            Button.margin(10);
            Button.onClick(() => {
                this.restartGame();
            });
        }, Button);
        Button.pop();
        // 控制按钮区域
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 操作说明
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(644:7)", "entry");
            // 操作说明
            Column.width('90%');
            // 操作说明
            Column.padding(15);
            // 操作说明
            Column.backgroundColor('#333333');
            // 操作说明
            Column.borderRadius(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('操作说明:');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(645:9)", "entry");
            Text.fontSize(16);
            Text.fontColor('#FFFFFF');
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ bottom: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('• 方向键: 控制吃豆人移动');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(651:9)", "entry");
            Text.fontSize(14);
            Text.fontColor('#FFFFFF');
            Text.margin({ bottom: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('• 空格键: 暂停/继续游戏');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(656:9)", "entry");
            Text.fontSize(14);
            Text.fontColor('#FFFFFF');
            Text.margin({ bottom: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('• Enter键: 开始游戏');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(661:9)", "entry");
            Text.fontSize(14);
            Text.fontColor('#FFFFFF');
            Text.margin({ bottom: 5 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('• 点击按钮: 控制游戏状态');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(666:9)", "entry");
            Text.fontSize(14);
            Text.fontColor('#FFFFFF');
        }, Text);
        Text.pop();
        // 操作说明
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
