/**
 * 游戏常量定义
 */
// 游戏状态
export class GameState {
    static readonly MENU = 'menu'; // 菜单
    static readonly PLAYING = 'playing'; // 游戏中
    static readonly PAUSED = 'paused'; // 暂停
    static readonly GAME_OVER = 'game_over'; // 游戏结束
    static readonly LEVEL_COMPLETE = 'level_complete'; // 关卡完成
}
// 方向
export class Direction {
    static readonly UP = 'up';
    static readonly DOWN = 'down';
    static readonly LEFT = 'left';
    static readonly RIGHT = 'right';
}
// 颜色常量
export class Colors {
    static readonly BACKGROUND = '#000000'; // 背景色
    static readonly WALL = '#0000FF'; // 墙壁颜色
    static readonly DOT = '#FFFFFF'; // 豆子颜色
    static readonly PACMAN = '#FFFF00'; // 吃豆人颜色
    static readonly GHOST_RED = '#FF0000'; // 红色幽灵
    static readonly GHOST_PINK = '#FFB8FF'; // 粉色幽灵
    static readonly GHOST_CYAN = '#00FFFF'; // 青色幽灵
    static readonly GHOST_ORANGE = '#FFB852'; // 橙色幽灵
    static readonly TEXT = '#FFFFFF'; // 文字颜色
    static readonly BUTTON_BG = '#333333'; // 按钮背景
    static readonly BUTTON_TEXT = '#FFFFFF'; // 按钮文字
}
// 游戏配置
export class GameConfig {
    static readonly GRID_SIZE = 15; // 网格大小（像素）
    static readonly MAZE_WIDTH = 28; // 迷宫宽度（网格数）
    static readonly MAZE_HEIGHT = 31; // 迷宫高度（网格数）
    static readonly DOT_SCORE = 10; // 豆子分数
    static readonly POWER_PELLET_SCORE = 50; // 大力丸分数
    static readonly LIVES = 3; // 初始生命数
    static readonly LEVEL_SCORE_MULTIPLIER = 1000; // 关卡分数乘数
}
// 地图元素
export class MapElements {
    static readonly WALL = '#'; // 墙壁
    static readonly PATH = '.'; // 路径（小豆子）
    static readonly POWER_PELLET = 'o'; // 大力丸
    static readonly EMPTY = ' '; // 空地
    static readonly PACMAN_START = 'P'; // 吃豆人起始位置
}
// 简化版迷宫地图（28x31）
export const MAZE_MAP: string[] = [
    '############################',
    '#............##............#',
    '#.####.#####.##.#####.####.#',
    '#o####.#####.##.#####.####o#',
    '#.####.#####.##.#####.####.#',
    '#..........................#',
    '#.####.##.########.##.####.#',
    '#.####.##.########.##.####.#',
    '#......##....##....##......#',
    '######.##### ## #####.######',
    '######.##### ## #####.######',
    '######.##          ##.######',
    '######.## ###  ### ##.######',
    '######.## #      # ##.######',
    '          #      #          ',
    '######.## #      # ##.######',
    '######.## ######## ##.######',
    '######.##          ##.######',
    '######.## ######## ##.######',
    '######.## ######## ##.######',
    '#............##............#',
    '#.####.#####.##.#####.####.#',
    '#.####.#####.##.#####.####.#',
    '#o..##................##..o#',
    '###.##.##.########.##.##.###',
    '###.##.##.########.##.##.###',
    '#......##....##....##......#',
    '#.##########.##.##########.#',
    '#.##########.##.##########.#',
    '#..........................#',
    '############################'
];
