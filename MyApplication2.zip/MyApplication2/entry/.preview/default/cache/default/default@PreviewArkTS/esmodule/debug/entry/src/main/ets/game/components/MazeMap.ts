if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MazeMap_Params {
    mazeData?: string[][];
    dots?: boolean[][];
    powerPellets?: boolean[][];
    onDotEaten?: (score: number) => void;
    onPowerPelletEaten?: (score: number) => void;
}
import { COLORS, GAME_CONFIG, MAZE_MAP, MAP_ELEMENTS } from "@normalized:N&&&entry/src/main/ets/game/GameConstants&";
export class MazeMap extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.mazeData = [];
        this.__dots = new ObservedPropertyObjectPU([], this, "dots");
        this.__powerPellets = new ObservedPropertyObjectPU([]
        // 分数回调
        , this, "powerPellets");
        this.onDotEaten = () => { };
        this.onPowerPelletEaten = () => { };
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MazeMap_Params) {
        if (params.mazeData !== undefined) {
            this.mazeData = params.mazeData;
        }
        if (params.dots !== undefined) {
            this.dots = params.dots;
        }
        if (params.powerPellets !== undefined) {
            this.powerPellets = params.powerPellets;
        }
        if (params.onDotEaten !== undefined) {
            this.onDotEaten = params.onDotEaten;
        }
        if (params.onPowerPelletEaten !== undefined) {
            this.onPowerPelletEaten = params.onPowerPelletEaten;
        }
    }
    updateStateVars(params: MazeMap_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__dots.purgeDependencyOnElmtId(rmElmtId);
        this.__powerPellets.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__dots.aboutToBeDeleted();
        this.__powerPellets.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 地图数据
    private mazeData: string[][];
    // 豆子状态（true表示豆子还在）
    private __dots: ObservedPropertyObjectPU<boolean[][]>;
    get dots() {
        return this.__dots.get();
    }
    set dots(newValue: boolean[][]) {
        this.__dots.set(newValue);
    }
    private __powerPellets: ObservedPropertyObjectPU<boolean[][]>;
    get powerPellets() {
        return this.__powerPellets.get();
    }
    set powerPellets(newValue: boolean[][]) {
        this.__powerPellets.set(newValue);
    }
    // 分数回调
    private onDotEaten: (score: number) => void;
    private onPowerPelletEaten: (score: number) => void;
    aboutToAppear() {
        this.initializeMaze();
    }
    /**
     * 初始化迷宫
     */
    private initializeMaze(): void {
        // 解析地图数据
        this.mazeData = MAZE_MAP.map(row => row.split(''));
        // 初始化豆子状态
        this.dots = [];
        this.powerPellets = [];
        for (let y = 0; y < GAME_CONFIG.MAZE_HEIGHT; y++) {
            this.dots[y] = [];
            this.powerPellets[y] = [];
            for (let x = 0; x < GAME_CONFIG.MAZE_WIDTH; x++) {
                const cell = this.mazeData[y][x];
                if (cell === MAP_ELEMENTS.PATH) {
                    this.dots[y][x] = true;
                    this.powerPellets[y][x] = false;
                }
                else if (cell === MAP_ELEMENTS.POWER_PELLET) {
                    this.dots[y][x] = false;
                    this.powerPellets[y][x] = true;
                }
                else {
                    this.dots[y][x] = false;
                    this.powerPellets[y][x] = false;
                }
            }
        }
    }
    /**
     * 检查指定位置是否可以通行
     */
    public canMoveTo(x: number, y: number): boolean {
        if (x < 0 || x >= GAME_CONFIG.MAZE_WIDTH || y < 0 || y >= GAME_CONFIG.MAZE_HEIGHT) {
            return false;
        }
        const cell = this.mazeData[y][x];
        return cell !== MAP_ELEMENTS.WALL;
    }
    /**
     * 吃豆子
     * @returns 获得的分数
     */
    public eatDot(x: number, y: number): number {
        if (x < 0 || x >= GAME_CONFIG.MAZE_WIDTH || y < 0 || y >= GAME_CONFIG.MAZE_HEIGHT) {
            return 0;
        }
        if (this.dots[y][x]) {
            this.dots[y][x] = false;
            this.onDotEaten(GAME_CONFIG.DOT_SCORE);
            return GAME_CONFIG.DOT_SCORE;
        }
        if (this.powerPellets[y][x]) {
            this.powerPellets[y][x] = false;
            this.onPowerPelletEaten(GAME_CONFIG.POWER_PELLET_SCORE);
            return GAME_CONFIG.POWER_PELLET_SCORE;
        }
        return 0;
    }
    /**
     * 获取剩余豆子数量
     */
    public getRemainingDots(): number {
        let count = 0;
        for (let y = 0; y < GAME_CONFIG.MAZE_HEIGHT; y++) {
            for (let x = 0; x < GAME_CONFIG.MAZE_WIDTH; x++) {
                if (this.dots[y][x] || this.powerPellets[y][x]) {
                    count++;
                }
            }
        }
        return count;
    }
    /**
     * 重置地图
     */
    public reset(): void {
        this.initializeMaze();
    }
    /**
     * 设置分数回调
     */
    public setScoreCallbacks(onDotEaten: (score: number) => void, onPowerPelletEaten: (score: number) => void): void {
        this.onDotEaten = onDotEaten;
        this.onPowerPelletEaten = onPowerPelletEaten;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 使用Grid布局绘制迷宫
            Grid.create();
            Grid.debugLine("entry/src/main/ets/game/components/MazeMap.ets(125:5)", "entry");
            // 使用Grid布局绘制迷宫
            Grid.columnsTemplate('1fr '.repeat(GAME_CONFIG.MAZE_WIDTH));
            // 使用Grid布局绘制迷宫
            Grid.rowsTemplate('1fr '.repeat(GAME_CONFIG.MAZE_HEIGHT));
            // 使用Grid布局绘制迷宫
            Grid.width(GAME_CONFIG.MAZE_WIDTH * GAME_CONFIG.GRID_SIZE);
            // 使用Grid布局绘制迷宫
            Grid.height(GAME_CONFIG.MAZE_HEIGHT * GAME_CONFIG.GRID_SIZE);
            // 使用Grid布局绘制迷宫
            Grid.backgroundColor(COLORS.BACKGROUND);
        }, Grid);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const y = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const x = _item;
                        // 绘制每个网格
                        this.renderCell.bind(this)(x, y);
                    };
                    this.forEachUpdateFunction(elmtId, Array.from({ length: GAME_CONFIG.MAZE_WIDTH }, (_, x) => x), forEachItemGenFunction);
                }, ForEach);
                ForEach.pop();
            };
            this.forEachUpdateFunction(elmtId, Array.from({ length: GAME_CONFIG.MAZE_HEIGHT }, (_, y) => y), forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        // 使用Grid布局绘制迷宫
        Grid.pop();
    }
    /**
     * 渲染单个网格
     */
    private renderCell(x: number, y: number, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/game/components/MazeMap.ets(149:5)", "entry");
            Column.width(GAME_CONFIG.GRID_SIZE);
            Column.height(GAME_CONFIG.GRID_SIZE);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (cell === MAP_ELEMENTS.WALL) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 墙壁
                        Row.create();
                        Row.debugLine("entry/src/main/ets/game/components/MazeMap.ets(152:9)", "entry");
                        // 墙壁
                        Row.width(GAME_CONFIG.GRID_SIZE);
                        // 墙壁
                        Row.height(GAME_CONFIG.GRID_SIZE);
                        // 墙壁
                        Row.backgroundColor(COLORS.WALL);
                        // 墙壁
                        Row.border({ width: 1, color: '#0000AA' });
                    }, Row);
                    // 墙壁
                    Row.pop();
                });
            }
            else if (hasDot) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 小豆子
                        Row.create();
                        Row.debugLine("entry/src/main/ets/game/components/MazeMap.ets(159:9)", "entry");
                        // 小豆子
                        Row.width(GAME_CONFIG.GRID_SIZE);
                        // 小豆子
                        Row.height(GAME_CONFIG.GRID_SIZE);
                        // 小豆子
                        Row.justifyContent(FlexAlign.Center);
                        // 小豆子
                        Row.alignItems(HorizontalAlign.Center);
                        // 小豆子
                        Row.backgroundColor(COLORS.BACKGROUND);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Circle.create({ width: GAME_CONFIG.GRID_SIZE / 4, height: GAME_CONFIG.GRID_SIZE / 4 });
                        Circle.debugLine("entry/src/main/ets/game/components/MazeMap.ets(160:11)", "entry");
                        Circle.fill(COLORS.DOT);
                    }, Circle);
                    // 小豆子
                    Row.pop();
                });
            }
            else if (hasPowerPellet) {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 大力丸
                        Row.create();
                        Row.debugLine("entry/src/main/ets/game/components/MazeMap.ets(170:9)", "entry");
                        // 大力丸
                        Row.width(GAME_CONFIG.GRID_SIZE);
                        // 大力丸
                        Row.height(GAME_CONFIG.GRID_SIZE);
                        // 大力丸
                        Row.justifyContent(FlexAlign.Center);
                        // 大力丸
                        Row.alignItems(HorizontalAlign.Center);
                        // 大力丸
                        Row.backgroundColor(COLORS.BACKGROUND);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Circle.create({ width: GAME_CONFIG.GRID_SIZE / 2, height: GAME_CONFIG.GRID_SIZE / 2 });
                        Circle.debugLine("entry/src/main/ets/game/components/MazeMap.ets(171:11)", "entry");
                        Circle.fill(COLORS.DOT);
                    }, Circle);
                    // 大力丸
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(3, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 空地
                        Row.create();
                        Row.debugLine("entry/src/main/ets/game/components/MazeMap.ets(181:9)", "entry");
                        // 空地
                        Row.width(GAME_CONFIG.GRID_SIZE);
                        // 空地
                        Row.height(GAME_CONFIG.GRID_SIZE);
                        // 空地
                        Row.backgroundColor(COLORS.BACKGROUND);
                    }, Row);
                    // 空地
                    Row.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
